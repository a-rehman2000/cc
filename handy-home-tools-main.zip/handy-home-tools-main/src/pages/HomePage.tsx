import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowRight, Hammer, PaintBucket, Wrench, Calendar, User } from "lucide-react";

const featuredPosts = [
  {
    id: 1,
    title: "10 Essential Tools Every Homeowner Should Have",
    excerpt: "From basic repairs to weekend projects, these tools will help you tackle any home improvement task.",
    category: "Tools & Equipment",
    readTime: "5 min read",
    image: "https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=600&h=400&fit=crop",
    date: "2024-01-15"
  },
  {
    id: 2,
    title: "Complete Kitchen Renovation Guide",
    excerpt: "Step-by-step guide to renovating your kitchen on any budget.",
    category: "Kitchen",
    readTime: "12 min read",
    image: "https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=600&h=400&fit=crop",
    date: "2024-01-12"
  },
  {
    id: 3,
    title: "Smart Home Automation Ideas",
    excerpt: "Transform your home with these affordable smart automation projects.",
    category: "Technology",
    readTime: "8 min read",
    image: "https://images.unsplash.com/photo-1558036117-15d82a90b9b1?w=600&h=400&fit=crop",
    date: "2024-01-10"
  }
];

const categories = [
  { name: "Kitchen", icon: PaintBucket, count: 24, color: "bg-red-100 text-red-700" },
  { name: "Bathroom", icon: Wrench, count: 18, color: "bg-blue-100 text-blue-700" },
  { name: "Outdoor", icon: Hammer, count: 32, color: "bg-green-100 text-green-700" },
  { name: "Electrical", icon: Wrench, count: 15, color: "bg-yellow-100 text-yellow-700" },
];

export function HomePage() {
  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-primary/10 via-background to-accent/10 py-20">
        <div className="container mx-auto px-4 lg:px-8">
          <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-4xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
              Transform Your Home With Expert Tips
            </h1>
            <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
              Discover practical home improvement guides, essential tools, and project calculators to make your dream home a reality.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button asChild size="lg" className="bg-gradient-to-r from-primary to-accent hover:opacity-90">
                <Link to="/blog">
                  Explore Guides
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
              <Button asChild variant="outline" size="lg">
                <Link to="/tools">
                  Use Our Tools
                  <Hammer className="ml-2 h-4 w-4" />
                </Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Posts */}
      <section className="py-16">
        <div className="container mx-auto px-4 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Featured Articles</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Our most popular home improvement guides and project tutorials
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {featuredPosts.map((post) => (
              <Card key={post.id} className="group hover:shadow-lg transition-shadow overflow-hidden">
                <div className="aspect-video overflow-hidden">
                  <img 
                    src={post.image} 
                    alt={post.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                  />
                </div>
                <CardHeader>
                  <div className="flex items-center justify-between mb-2">
                    <Badge variant="secondary">{post.category}</Badge>
                    <span className="text-sm text-muted-foreground">{post.readTime}</span>
                  </div>
                  <CardTitle className="group-hover:text-primary transition-colors">
                    <Link to={`/blog/${post.id}`}>{post.title}</Link>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription>{post.excerpt}</CardDescription>
                  <div className="flex items-center mt-4 text-sm text-muted-foreground">
                    <Calendar className="h-4 w-4 mr-1" />
                    {new Date(post.date).toLocaleDateString()}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="text-center mt-12">
            <Button asChild variant="outline">
              <Link to="/blog">
                View All Articles
                <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Categories */}
      <section className="py-16 bg-muted/50">
        <div className="container mx-auto px-4 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4">Browse by Category</h2>
            <p className="text-muted-foreground">
              Find exactly what you're looking for
            </p>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {categories.map((category) => (
              <Link key={category.name} to={`/categories/${category.name.toLowerCase()}`}>
                <Card className="text-center hover:shadow-lg transition-shadow group">
                  <CardContent className="pt-6">
                    <div className={`w-16 h-16 rounded-full ${category.color} mx-auto mb-4 flex items-center justify-center group-hover:scale-110 transition-transform`}>
                      <category.icon className="h-8 w-8" />
                    </div>
                    <h3 className="font-semibold mb-2">{category.name}</h3>
                    <p className="text-sm text-muted-foreground">{category.count} articles</p>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Tools Section */}
      <section className="py-16">
        <div className="container mx-auto px-4 lg:px-8">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-3xl font-bold mb-4">Free Home Improvement Tools</h2>
            <p className="text-muted-foreground mb-8">
              Calculate costs, plan projects, and make informed decisions with our free tools
            </p>
            
            <Card className="bg-gradient-to-br from-primary/5 to-accent/5 border-primary/20">
              <CardContent className="pt-8">
                <div className="flex items-center justify-center mb-6">
                  <div className="bg-gradient-to-br from-primary to-accent p-4 rounded-full">
                    <Hammer className="h-8 w-8 text-white" />
                  </div>
                </div>
                <h3 className="text-2xl font-bold mb-4">Project Cost Calculator</h3>
                <p className="text-muted-foreground mb-6">
                  Get accurate cost estimates for your home improvement projects
                </p>
                <Button asChild size="lg" className="bg-gradient-to-r from-primary to-accent">
                  <Link to="/tools/calculator">
                    Try Calculator
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Link>
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>
    </div>
  );
}