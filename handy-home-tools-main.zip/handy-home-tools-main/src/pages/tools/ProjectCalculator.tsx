import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Separator } from "@/components/ui/separator";
import { Calculator, DollarSign, Clock, AlertTriangle } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";

const projectTypes = {
  "kitchen-renovation": {
    name: "Kitchen Renovation",
    baseCost: 15000,
    laborMultiplier: 0.3,
    materialMultiplier: 0.7,
    timeWeeks: 6
  },
  "bathroom-renovation": {
    name: "Bathroom Renovation",
    baseCost: 8000,
    laborMultiplier: 0.35,
    materialMultiplier: 0.65,
    timeWeeks: 4
  },
  "deck-building": {
    name: "Deck Building",
    baseCost: 5000,
    laborMultiplier: 0.4,
    materialMultiplier: 0.6,
    timeWeeks: 2
  },
  "room-addition": {
    name: "Room Addition",
    baseCost: 25000,
    laborMultiplier: 0.45,
    materialMultiplier: 0.55,
    timeWeeks: 12
  },
  "flooring": {
    name: "Flooring Installation",
    baseCost: 3000,
    laborMultiplier: 0.25,
    materialMultiplier: 0.75,
    timeWeeks: 1
  }
};

const qualityLevels = {
  "budget": { name: "Budget", multiplier: 0.7 },
  "mid-range": { name: "Mid-Range", multiplier: 1.0 },
  "high-end": { name: "High-End", multiplier: 1.5 },
  "luxury": { name: "Luxury", multiplier: 2.0 }
};

export function ProjectCalculator() {
  const [projectType, setProjectType] = useState("");
  const [quality, setQuality] = useState("mid-range");
  const [squareFootage, setSquareFootage] = useState("");
  const [laborRate, setLaborRate] = useState("50");
  const [results, setResults] = useState(null);

  const calculateCost = () => {
    if (!projectType || !squareFootage) return;

    const project = projectTypes[projectType];
    const qualityMult = qualityLevels[quality].multiplier;
    const sqft = parseInt(squareFootage);
    const hourlyRate = parseInt(laborRate);

    // Base calculations
    const materialCost = project.baseCost * qualityMult * (sqft / 100);
    const laborHours = (sqft * 2) + (project.timeWeeks * 40);
    const laborCost = laborHours * hourlyRate;
    
    const subtotal = materialCost + laborCost;
    const permitFees = subtotal * 0.02; // 2% for permits
    const contingency = subtotal * 0.15; // 15% contingency
    const total = subtotal + permitFees + contingency;

    setResults({
      materialCost,
      laborCost,
      laborHours,
      permitFees,
      contingency,
      subtotal,
      total,
      timeWeeks: project.timeWeeks,
      pricePerSqft: total / sqft
    });
  };

  const formatCurrency = (amount) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(amount);
  };

  return (
    <div className="min-h-screen py-12">
      <div className="container mx-auto px-4 lg:px-8 max-w-4xl">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="bg-gradient-to-br from-primary to-accent p-4 rounded-full w-16 h-16 mx-auto mb-6 flex items-center justify-center">
            <Calculator className="h-8 w-8 text-white" />
          </div>
          <h1 className="text-4xl font-bold mb-4">Project Cost Calculator</h1>
          <p className="text-xl text-muted-foreground">
            Get accurate cost estimates for your home improvement projects
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Input Form */}
          <Card>
            <CardHeader>
              <CardTitle>Project Details</CardTitle>
              <CardDescription>
                Enter your project information to get a cost estimate
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="project-type">Project Type</Label>
                <Select value={projectType} onValueChange={setProjectType}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select project type" />
                  </SelectTrigger>
                  <SelectContent>
                    {Object.entries(projectTypes).map(([key, project]) => (
                      <SelectItem key={key} value={key}>
                        {project.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="quality">Quality Level</Label>
                <Select value={quality} onValueChange={setQuality}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {Object.entries(qualityLevels).map(([key, level]) => (
                      <SelectItem key={key} value={key}>
                        {level.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="square-footage">Square Footage</Label>
                <Input
                  id="square-footage"
                  type="number"
                  placeholder="Enter square footage"
                  value={squareFootage}
                  onChange={(e) => setSquareFootage(e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="labor-rate">Labor Rate ($/hour)</Label>
                <Input
                  id="labor-rate"
                  type="number"
                  placeholder="Enter hourly labor rate"
                  value={laborRate}
                  onChange={(e) => setLaborRate(e.target.value)}
                />
              </div>

              <Button 
                onClick={calculateCost} 
                className="w-full bg-gradient-to-r from-primary to-accent"
                disabled={!projectType || !squareFootage}
              >
                Calculate Cost
              </Button>
            </CardContent>
          </Card>

          {/* Results */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <DollarSign className="h-5 w-5 mr-2" />
                Cost Breakdown
              </CardTitle>
              <CardDescription>
                Detailed estimate for your project
              </CardDescription>
            </CardHeader>
            <CardContent>
              {results ? (
                <div className="space-y-6">
                  {/* Summary */}
                  <div className="bg-gradient-to-br from-primary/5 to-accent/5 p-4 rounded-lg">
                    <div className="text-center">
                      <p className="text-sm text-muted-foreground mb-1">Total Estimated Cost</p>
                      <p className="text-3xl font-bold text-primary">
                        {formatCurrency(results.total)}
                      </p>
                      <p className="text-sm text-muted-foreground mt-1">
                        {formatCurrency(results.pricePerSqft)} per sq ft
                      </p>
                    </div>
                  </div>

                  {/* Breakdown */}
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span>Materials</span>
                      <span className="font-medium">{formatCurrency(results.materialCost)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Labor ({results.laborHours} hours)</span>
                      <span className="font-medium">{formatCurrency(results.laborCost)}</span>
                    </div>
                    <Separator />
                    <div className="flex justify-between">
                      <span>Subtotal</span>
                      <span className="font-medium">{formatCurrency(results.subtotal)}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Permits & Fees (2%)</span>
                      <span>{formatCurrency(results.permitFees)}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Contingency (15%)</span>
                      <span>{formatCurrency(results.contingency)}</span>
                    </div>
                    <Separator />
                    <div className="flex justify-between text-lg font-bold">
                      <span>Total</span>
                      <span>{formatCurrency(results.total)}</span>
                    </div>
                  </div>

                  {/* Timeline */}
                  <div className="flex items-center p-3 bg-muted rounded-lg">
                    <Clock className="h-5 w-5 mr-3 text-muted-foreground" />
                    <div>
                      <p className="font-medium">Estimated Timeline</p>
                      <p className="text-sm text-muted-foreground">
                        {results.timeWeeks} week{results.timeWeeks !== 1 ? 's' : ''}
                      </p>
                    </div>
                  </div>

                  <Alert>
                    <AlertTriangle className="h-4 w-4" />
                    <AlertDescription>
                      This is an estimate only. Actual costs may vary based on location, 
                      specific materials, and unforeseen complications.
                    </AlertDescription>
                  </Alert>
                </div>
              ) : (
                <div className="text-center py-12 text-muted-foreground">
                  <Calculator className="h-12 w-12 mx-auto mb-4 opacity-50" />
                  <p>Enter project details to see cost breakdown</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Tips */}
        <Card className="mt-8">
          <CardHeader>
            <CardTitle>Money-Saving Tips</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <h4 className="font-medium">DIY Where Possible</h4>
                <p className="text-sm text-muted-foreground">
                  Painting, demolition, and simple installations can save 20-30% on labor costs.
                </p>
              </div>
              <div className="space-y-2">
                <h4 className="font-medium">Shop Around</h4>
                <p className="text-sm text-muted-foreground">
                  Get multiple quotes and compare material prices from different suppliers.
                </p>
              </div>
              <div className="space-y-2">
                <h4 className="font-medium">Time It Right</h4>
                <p className="text-sm text-muted-foreground">
                  Off-season projects often have lower labor costs and better contractor availability.
                </p>
              </div>
              <div className="space-y-2">
                <h4 className="font-medium">Plan Ahead</h4>
                <p className="text-sm text-muted-foreground">
                  Detailed planning reduces changes and unexpected costs during construction.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}