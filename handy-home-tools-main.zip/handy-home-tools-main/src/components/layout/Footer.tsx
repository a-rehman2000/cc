import { Link } from "react-router-dom";
import { Home, Mail, Phone, MapPin } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

export function Footer() {
  return (
    <footer className="bg-muted/50 border-t">
      <div className="container mx-auto px-4 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="space-y-4">
            <Link to="/" className="flex items-center space-x-2">
              <div className="bg-gradient-to-br from-primary to-accent p-2 rounded-lg">
                <Home className="h-6 w-6 text-white" />
              </div>
              <span className="text-xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
                HandyTools
              </span>
            </Link>
            <p className="text-muted-foreground">
              Your ultimate resource for home improvement tips, tools, and inspiration.
            </p>
          </div>

          {/* Quick Links */}
          <div className="space-y-4">
            <h3 className="font-semibold">Quick Links</h3>
            <ul className="space-y-2">
              <li><Link to="/blog" className="text-muted-foreground hover:text-primary">Blog</Link></li>
              <li><Link to="/tools" className="text-muted-foreground hover:text-primary">Tools</Link></li>
              <li><Link to="/categories" className="text-muted-foreground hover:text-primary">Categories</Link></li>
              <li><Link to="/admin" className="text-muted-foreground hover:text-primary">Admin</Link></li>
            </ul>
          </div>

          {/* Categories */}
          <div className="space-y-4">
            <h3 className="font-semibold">Categories</h3>
            <ul className="space-y-2">
              <li><Link to="/categories/kitchen" className="text-muted-foreground hover:text-primary">Kitchen</Link></li>
              <li><Link to="/categories/bathroom" className="text-muted-foreground hover:text-primary">Bathroom</Link></li>
              <li><Link to="/categories/outdoor" className="text-muted-foreground hover:text-primary">Outdoor</Link></li>
              <li><Link to="/categories/electrical" className="text-muted-foreground hover:text-primary">Electrical</Link></li>
            </ul>
          </div>

          {/* Newsletter */}
          <div className="space-y-4">
            <h3 className="font-semibold">Stay Updated</h3>
            <p className="text-muted-foreground text-sm">
              Get the latest home improvement tips and project ideas.
            </p>
            <div className="flex space-x-2">
              <Input placeholder="Enter your email" />
              <Button>Subscribe</Button>
            </div>
          </div>
        </div>

        <div className="mt-8 pt-8 border-t">
          <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
            <p className="text-muted-foreground text-sm">
              © 2024 HandyTools. All rights reserved.
            </p>
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2 text-muted-foreground text-sm">
                <Mail className="h-4 w-4" />
                <span>contact@handytools.com</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}